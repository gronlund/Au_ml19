import numpy as np
import random
import scipy.io as sio
import networkx as nx
from gensim.models import Word2Vec
import time

def build_adjacency_list(graph) : 
    """ Returns the adjacency list of a graph

        Args:
            graph: the input graph

        :return The graph represented as an adjaceny list
    """
    adj = []
    ### YOUR CODE HERE
    ### YOUR CODE HERE
    return adj



def random_walk(adj_list, walk_length, start, alpha):
    """ Returns a random walk

        Args:
            adj_list: the adjacency list of the graph
            walk_length: length of the random walk
            alpha: dumping factor
            start: the start node of the random walk.

        :return a single random walk starting from a node
    """
    n = len(adj_list)
    path = [start]

    ### YOUR CODE HERE
    ### YOUR CODE HERE
    return [str(node) for node in path]



def build_graph_walks(adj_list, walk_per_node = 10, walk_length = 40, alpha = 1):
    """ Returns a corpus of random walk from each node in the graph

        Args:
            walk_per_node: the number of random walks for each node
            path_length: length of the random walk
            alpha: probability of restarts.

        :return a list of random walks
    """
    walks = []
    nodes = np.arange(adj_list.size)

    ### YOUR CODE HERE
    ### YOUR CODE HERE
    return walks


if __name__ == '__main__':
    random.seed(12234513)

    blogcatalog = sio.loadmat('blogcatalog.mat')
    graph_mat = blogcatalog['network']
    G = nx.Graph()

    cx = graph_mat.tocoo()
    for i, j, v in zip(cx.row, cx.col, cx.data):
        G.add_edge(i, j)

    n = G.number_of_nodes()
    m = G.number_of_edges()

    adj_list = build_adjacency_list(G)

    print("Creating random walks")
    t = time.time()
    walks = build_graph_walks(adj_list)
    print()
    print("Generated {} walks in {} seconds".format(len(walks), time.time() - t))

    print("Training the model")
    t = time.time()
    model = Word2Vec(walks, size = 128, window = 10, min_count = 0, sg = 1, hs = 1, workers = 4, iter = 5)
    print("Training time:", time.time() - t)

    model.wv.save_word2vec_format("rwemb.w2v")
    print("Embedding saved into rwemb.w2v")
