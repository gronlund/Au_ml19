import numpy as np
import networkx as nx
import random
import scipy.io as sio
import time


def pagerank_matrix(G, alpha = 0.85) :     
    ''' Return the PPR matrix of a graph

        Args:
            G: the input graph
            alpha: 1 - Restart probability

        :return The nxn PageRank matrix P
    '''
    ### YOUR CODE HERE
    ### YOUR CODE HERE
    return P
    
def sigmoid(x):
    ''' Return the sigmoid function of x 
        x: the input vector
    '''
    if x > 6.0:
        return 1.0
    elif x < - 6.0:
        return 0.0
    return 1/(1 + np.exp(-x))


def verse(G, S, d, k = 3, step_size = 0.0025, steps = 10000): 
    ''' Return the sampled version of VERSE

        Args:
            G: the input Graph
            S: the PageRank similarity matrix
            d: dimension of the
            k: number of negative samples
            step_size: step size for gradient descent
            steps: number of iterations

        :return the embedding matrix nxd
    '''
    n = G.number_of_nodes()
    Z = 1/d*np.random.rand(n,d)

    ### YOUR CODE HERE
    ### YOUR CODE HERE
    return Z

def update(u, v, Z, C, step_size) :
    '''Update the matrix Z using row-wise gradients of the loss function

       Args:
           u : the first node
           v : the second node
           Z : the embedding matrix
           C : the classification variable used in Noise Contrastive estimation indicating whether the sample is positive or negative

       :return nothing, just update rows Z[v,:] and and Z[u,:]
    '''
    ### YOUR CODE HERE
    ### YOUR CODE HERE


if __name__ == '__main__':
    random.seed(12234513)

    blogcatalog = sio.loadmat('blogcatalog.mat')
    graph_mat = blogcatalog['network']
    G = nx.Graph()

    cx = graph_mat.tocoo()
    for i, j, v in zip(cx.row, cx.col, cx.data):
        G.add_edge(i, j)

    print("Loaded graph")
    print("nodes={}, edges={}".format(G.number_of_nodes(), G.number_of_edges()))

    print("Computing PageRank Matrix")
    cur_time = time.time()
    P = pagerank_matrix(G)
    print("PageRank Matrix computed in {} seconds".format(time.time() - cur_time))
    print("Computing embeddings")
    cur_time = time.time()
    emb = verse(G, P, 128, step_size=0.0025, steps=10_000)
    print("Embedding computed in {} seconds".format(time.time() - cur_time))

    np.save('verse.npy', emb)
    print("Embedding saved")




